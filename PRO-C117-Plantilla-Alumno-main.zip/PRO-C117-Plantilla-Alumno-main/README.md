# PRO-C117-Plantilla-Alumno
Para completar este proyecto, asegúrate de que has:
1) Descargado todos los archivos de este repositorio.
2) Creado un entorno virtual.
3) Instalado las librerías necesarias como Flask, Pandas, Tensorflow.
